using MASHP
using Test

@testset "MASHP.jl" begin
    # Write your tests here.
end
