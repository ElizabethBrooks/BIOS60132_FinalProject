module MASHP

#Add necessary packages
#Pkg.add("Bio")
#Pkg.add("DataFrames")
#Pkg.add("CSV")

#Load packages
using Bio.Seq
using Bio.Var
using DataFrames
using CSV

#Function to determine Jaccard distances from MinHash sketches
function minJD(merSize,sketchSize,nameDF,nameMatrix,numSpecies,outputDist)
	#Initialize data vectors
	readList=Array{BioSequences.FASTA.Reader}(undef,numSpecies)
	sketchList=Array{MinHashSketch}(undef,numSpecies)
	nameList=Array{String}(undef,numSpecies)
	distMat=zeros(numSpecies,numSpecies)

	#Sketch FASTA files
	nameList[1]="species"
	for i in 1:numSpecies
		#Read input FASTA files
		println("Reading FASTA file ", nameMatrix[i,2])
		reads=open(FASTA.Reader, nameMatrix[i,2])
		readList[i]=reads
		#Generate MinHash sketches for each species
		println("Generating MinHash sketch for ", nameMatrix[i,1])
		sketch=minhash(reads, merSize, sketchSize)
		sketchList[i]=sketch
		#Create name vector for header
		nameList[i]=nameMatrix[i,1]
	end

	#Calculate pair-wise Jaccard distances
	println("Calculating Jaccard distances...")
	for i in 1:numSpecies
		for j in 1:numSpecies
			if i < j
				#Determine jaccard distance
				dist=GeneticVariation.distance(Jaccard, sketchList[i], sketchList[j])
				distMat[i,j]=1-dist
				distMat[j,i]=1-dist
			end
		end
	end

	#Output distance matrix to CSV
	distDF=DataFrame(distMat)
	CSV.write(outputDist, DataFrame(distMat), header=nameList)

	#Return the distance matrix
	return distMat
end

end
